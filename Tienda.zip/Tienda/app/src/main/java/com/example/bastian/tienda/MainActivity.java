package com.example.bastian.tienda;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class MainActivity extends BaseActivity {


    String asd;
    ListView list;
    String[] poleras = {
            "Polera Azul",
            "Polera Roja",
            "Polera Negra",
            "Polera Verde",
            "Polera Naranja"
    } ;
    String[] descripciones = {
            "Esta es una polera Roja",
            "Esta es una polera Azul",
            "Esta es una Polera Negra",
            "Esta es una Polera Verde",
            "Esta es una Polera Naranja"

    } ;
    String[] precios = {
            "7900",
            "8900",
                "5900",
            "5900",
            "4990"
    } ;
    Integer[] imageId = {
            R.drawable.polera1,
            R.drawable.polera2,
            R.drawable.polera3,
            R.drawable.polera4,
            R.drawable.polera5
           };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        CustomList adapter = new
                CustomList(MainActivity.this, poleras, imageId, descripciones, precios);
        list=(ListView)findViewById(R.id.lista_productos);
        list.setAdapter(adapter);
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {

            }
        });

    }

    public class CustomList extends ArrayAdapter<String>{

        private final Activity context;
        private final String[] poleras;
        private final Integer[] imageId;
        private final String[] descripciones;
        private final String[] precios;
        private RelativeLayout relativeLayout;


        public CustomList(Activity context,
                          String[] poleras, Integer[] imageId, String[] descripciones, String[] precios) {
            super(context, R.layout.cell_list_view, poleras);
            this.context = context;
            this.poleras = poleras;
            this.imageId = imageId;
            this.descripciones = descripciones;
            this.precios = precios;

        }

        @Override
        public String getItem(int position) {
            return super.getItem(position);
        }

        @Override
        public View getView(final int position, View view, ViewGroup parent) {
            LayoutInflater inflater = context.getLayoutInflater();
            View rowView= inflater.inflate(R.layout.cell_list_view, null, true);

            ImageView imageView = (ImageView) rowView.findViewById(R.id.img);

            relativeLayout = (RelativeLayout) rowView.findViewById(R.id.relative_layout);

            TextView txtTitulo = (TextView) rowView.findViewById(R.id.titulo);
            TextView txtDescripcion = (TextView) rowView.findViewById(R.id.descripcion);
            TextView txtPrecio = (TextView) rowView.findViewById(R.id.precio);

            relativeLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Log.v("BL", "Se ha cliqueado la celda numero " + position);
                    Intent intent = new Intent(getBaseContext(), DescripcionActivity.class);
                    intent.putExtra("titulo", poleras[position]);
                    intent.putExtra("descripcion", descripciones[position]);
                    intent.putExtra("precio", precios[position]);
                    intent.putExtra("image", position);
                    startActivity(intent);
                    context.overridePendingTransition(R.anim.to_right, R.anim.to_left);

                }
            });

            txtTitulo.setText(poleras[position]);
            txtDescripcion.setText(descripciones[position]);
            txtPrecio.setText("$"+precios[position]);

            imageView.setImageResource(imageId[position]);

            return rowView;
        }
    }
}
