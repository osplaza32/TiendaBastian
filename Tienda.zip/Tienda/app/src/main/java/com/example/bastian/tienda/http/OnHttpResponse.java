package com.example.bastian.tienda.http;

/**
 * Created by Bastian on 08-10-2017.
 */

public interface OnHttpResponse {

    void onHttpResponse(HttpResponse response);

}